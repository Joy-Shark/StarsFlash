<template>
   <div id="app">
    <div class="header_txt">
      <div class="title_y">TJW云盘</div>
     
      <ShareLink />

    </div>

    <div class="title_small_y">上传、下载自己的文件</div>

    <div class="file_upload_container">
      <div class="inner_wrap">
        <div class="upload_btn">
          <!-- <span>点击上传文件</span> -->
          <input type="file" name="filename" id="" />
        </div>
      </div>
    </div>

    <el-backtop></el-backtop>
  </div>
</template>

<script>
export default {
    name:"TjwContent"
}
</script>


<style lang="less">
body {
  font-family: "字体圈欣意吉祥宋";
}
nav {
  .Header_left {
    display: flex;
    line-height: 41px;
    .Logo_title {
      font-size: 20px;
      margin-left: 10px;
    }
  }
  display: flex;
  justify-content: space-between;
  padding: 30px;
  .Header_Logo {
    flex: 2;
    display: inline-block;
    flex-shrink: 0;
    width: 41px;
    height: 41px;
    line-height: 41px;
    background: url(https://m4.publicimg.browser.qq.com/publicimg/nav/qbtool/logo.png)
      no-repeat 50%;
    background-position-y: 40%;
    background-position-x: center;
    background-size: contain;
    border-radius: 50%;
    cursor: pointer;
  }

  a {
    font-weight: bold;
    font-size: 18px;
    color: #2c3e50;
    text-decoration: none;

    .b:active {
      background-color: #2c3e50;
    }
  }
}
.header_txt {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 20px;
  margin-left: 120px;
}
.title_y {
  font-size: 30px;
  font-weight: 600;
  word-spacing: 100px;
  margin: 10px auto;
}
// .share {
//   margin-right: 30px;
//   width: 136px;
//   line-height: 44px;
//   background: #1f7efb;
//   opacity: 0.6;
//   border-radius: 8px;
//   font-size: 16px;
//   color: #fff;
//   text-align: center;
//   border: none;
// }
.title_small_y {
  width: 965px;
  height: 40px;
  margin: 10px 75px;
  padding: 10px;
  text-align: center;
}
.file_upload_container {
  position: relative;
  padding-top: 40%;
}
.inner_wrap {
  width: 100%;
  height: 100%;
  top: -10px;
  left: 0;
  position: absolute;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  border: 2px dashed #e2e2e2;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
  border-radius: 24px;
  background-color: #fff;
}
.upload_btn {
  padding: 8px 30px;
  text-align: center;
  background: #136ce9;
  border-radius: 8px;
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  color: #fafafa;
  cursor: pointer;
}

.desc1 {
  font-size: 20px;
  margin-left: 25px;
  margin-top: 10px;
}
</style>