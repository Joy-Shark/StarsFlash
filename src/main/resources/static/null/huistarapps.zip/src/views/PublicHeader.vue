<template>
  <div class="th">
    <nav class="Nav">
      <router-link class="Header_left" to="/">
        <i class="Header_Logo"></i>
        <div class="Logo_title">绘星工具箱-"帮小忙,也能帮大忙"</div>
      </router-link>

      <div>
        <router-link to="/"><el-tag class="b">全部</el-tag></router-link> |
        <router-link to="/clouddisk"
          ><el-tag class="b1" type="success">云盘</el-tag></router-link
        >|
        <router-link to="/candv"
          ><el-tag class="b2" type="success">CV字符串</el-tag></router-link
        >
        |

        <router-link to="/todolist"
          ><el-tag class="b2" type="success">ToDoList</el-tag></router-link
        >
        |
        <router-link to="/randomtext"
          ><el-tag class="b1" type="success">随机文案</el-tag></router-link
        >
        |
        <router-link to="/pwdval"
          ><el-tag class="b2" type="success">密码格式验证</el-tag></router-link
        >
        |
      </div>
    </nav>
    <div
      class="header_txtA"
      v-if="
        $route.path != '/diskcontent' &&
        $route.path != '/tjwdiskcontent' &&
        $route.path != '/candvcontent'
      "
    >
      <div class="title_A">工欲善其事,必先利其器</div>

      <ShareLink />
    </div>

    <!-- <div
      class="desc1"
      v-if="
      $route.path != '/diskcontent'
      && 
      $route.path != '/tjwdiskcontent'
      && 
      $route.path != '/candvcontent'
      " 
    >
      Try Our Best!!!
    </div>

    <div
      class="search"
      v-if="
      $route.path != '/diskcontent' 
      && 
      $route.path != '/tjwdiskcontent'
      &&
      $route.path != '/candvcontent'
    
      "
    >
      <div class="search_icon">
        <img
          class="searchsession"
          src="https://m4.publicimg.browser.qq.com/publicimg/nav/qbtool/search-icon.png
"
          alt=""
          @click="searchAddress"
        />
        <span class="searchspantxt"></span>
        <input type="text" class="search_input" placeholder="搜索想要的工具" v-model="keyword" />
      </div>
    </div> -->

    <SearchView  />

    <el-backtop></el-backtop>
    <router-view />
  </div>
</template>

<script>
import SearchView from "./SearchView.vue";

export default {
  name: "pubheader",
  data() {
    return {
      visible: false,
    };
  },
  components: {
    SearchView,
  },

};
</script>
