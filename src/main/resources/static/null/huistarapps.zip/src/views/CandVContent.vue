<template>
    <div id="app">
      <div class="header_txt">
        <div class="title_y">字符串中转</div>
       
        <ShareLink />
  
      </div>
  
      <div class="title_small_y">方便快捷,告别通过微信QQ复制粘贴</div>
  
      <div class="file_upload_container">
          <input type="text" class="inner_wrap" placeholder="粘贴你需要的文本或者链接" />
      </div>
  
      <el-backtop></el-backtop>
    </div>
  </template>
  
  <script>
  export default {
    name: "canv",
    data() {
      return {
        visible: false,

      };
    },
   
  };
  </script>
  
  
  <style lang="less">
  body {
    font-family: "字体圈欣意吉祥宋";
  }
  nav {
    .Header_left {
      display: flex;
      line-height: 41px;
      .Logo_title {
        font-size: 20px;
        margin-left: 10px;
      }
    }
    display: flex;
    justify-content: space-between;
    padding: 30px;
    .Header_Logo {
      flex: 2;
      display: inline-block;
      flex-shrink: 0;
      width: 41px;
      height: 41px;
      line-height: 41px;
      background: url(https://m4.publicimg.browser.qq.com/publicimg/nav/qbtool/logo.png)
        no-repeat 50%;
      background-position-y: 40%;
      background-position-x: center;
      background-size: contain;
      border-radius: 50%;
      cursor: pointer;
    }
  
    a {
      font-weight: bold;
      font-size: 18px;
      color: #2c3e50;
      text-decoration: none;
  
      .b:active {
        background-color: #2c3e50;
      }
    }
  }
  .header_txt {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 20px;
    margin-left: 120px;
  }
  .title_y {
    font-size: 30px;
    font-weight: 600;
    word-spacing: 100px;
    margin: 10px auto;
  }

  .title_small_y {
    width: 965px;
    height: 40px;
    margin: 10px 75px;
    padding: 10px;
  }
  .file_upload_container {
    position: relative;
    }
  .inner_wrap {
    width: 90%;
    height: 100%;
    position: absolute;
    display: flex;
    flex-direction: column;
    flex-wrap: wrap;
    border: 2px dashed #e2e2e2;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
    border-radius: 24px;
    background-color: #fff;
    font-size: 24px;
    padding-left: 30px;
    padding-right: 30px;
  }
  .upload_btn {
    padding: 8px 30px;
    text-align: center;
    background: #136ce9;
    border-radius: 8px;
    font-style: normal;
    font-weight: 400;
    font-size: 14px;
    color: #fafafa;
    cursor: pointer;
  }
  
  .desc1 {
    font-size: 20px;
    margin-left: 25px;
    margin-top: 10px;
  }
  </style>
  
  
  