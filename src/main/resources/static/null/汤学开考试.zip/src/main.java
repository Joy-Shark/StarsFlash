public class main {
    public static void main(String[] args) {

//        公鸡 5   母鸡 3   小鸡 1文3只
        for (int g = 0;g<20;g++){
            for (int m = 0;m<100;m++){
                int s = 100-g-m;
                if(g*5+m*3+s/3==100 && g+m+s==100){
                    System.out.printf("公鸡：%d，母鸡：%d，小鸡：%d！\n", g, m, s);
                }
            }
        }
    }
}
