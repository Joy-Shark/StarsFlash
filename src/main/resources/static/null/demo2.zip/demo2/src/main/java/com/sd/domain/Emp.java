package com.sd.domain;

public class Emp {
    private Integer id ;
    private String name;
    private Integer dept_id;

    public Emp() {
    }

    public Emp(Integer id, String name, Integer dept_id) {
        this.id = id;
        this.name = name;
        this.dept_id = dept_id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getDept_id() {
        return dept_id;
    }

    public void setDept_id(Integer dept_id) {
        this.dept_id = dept_id;
    }

    @Override
    public String toString() {
        return "Emp{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", dept_id=" + dept_id +
                '}';
    }
}
