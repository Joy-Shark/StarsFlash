package com.sd;

import com.sd.controller.BasicController;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 *
 */
@RunWith(SpringRunner.class)//加载springboot测试注解
@SpringBootTest //表示该类是个测试类
public class helloTest {
    @Autowired
    private BasicController basicController;
    @Test
    public void helloBasicController(){
       String hello= basicController.hello("zhangs");
        System.out.println(hello);
    }
}
