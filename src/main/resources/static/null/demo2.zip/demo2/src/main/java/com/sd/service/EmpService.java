package com.sd.service;

import com.sd.domain.Emp;

import java.util.List;

/**
 *
 */
public interface EmpService {
    //查询所有
    List<Emp> findEmps();


}
