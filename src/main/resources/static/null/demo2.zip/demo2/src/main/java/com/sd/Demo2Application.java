package com.sd;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;

import javax.annotation.ManagedBean;



@SpringBootApplication
//指定要变成实现类的接口所在的包，然后包下面的所有接口在编译之后都会生成相应的实现类
//添加位置：是在Springboot启动类上面添加，
////需要加上这个注解：扫描Mapper接口，生成Mapper接口的代理对象，然后才能在Service中注入使用，否则注入失败
@MapperScan("com.sd.mapper")
public class Demo2Application {

    public static void main(String[] args) {

       SpringApplication.run(Demo2Application.class, args);

    }

}
