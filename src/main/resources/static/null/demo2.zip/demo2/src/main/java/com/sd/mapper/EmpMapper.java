package com.sd.mapper;

import com.sd.domain.Emp;

import java.util.List;

public interface EmpMapper {
    List<Emp> findEmps();

}
