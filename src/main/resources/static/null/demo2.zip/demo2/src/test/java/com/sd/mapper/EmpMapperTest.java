package com.sd.mapper;

import com.sd.Demo2Application;
import com.sd.service.EmpService;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.SQLOutput;

import static org.junit.jupiter.api.Assertions.*;
@RunWith(SpringRunner.class)
@SpringBootTest(classes = Demo2Application.class)
class EmpMapperTest {
    @Autowired
    private  EmpService empService;
    @Test
    void findEmps() {
        empService.findEmps().forEach(System.out::println);
    }
}